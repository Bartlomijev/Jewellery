 package app;


public class ShopApp {
	public static void main(String[] args) {
		final String appName = "Zakład produkcyjno-usługowy v0.1";
		System.out.println(appName);
	AppControl app = new AppControl();
	app.chooseOption();

}
}
